"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["6660"],{93444:function(e,a,t){var o=t(40445),r=t(96196),i=t(77845);let s,l,d=e=>e;class h extends r.WF{render(){return(0,r.qy)(s||(s=d` <footer> <slot name="secondaryAction"></slot> <slot name="primaryAction"></slot> </footer> `))}static get styles(){return[(0,r.AH)(l||(l=d`footer{display:flex;gap:var(--ha-space-3);justify-content:flex-end;align-items:center;width:100%}`))]}}h=(0,o.Cg)([(0,i.EM)("ha-dialog-footer")],h)},76538:function(e,a,t){t(62953);var o=t(40445),r=t(96196),i=t(77845);let s,l,d,h,n,c,p=e=>e;class g extends r.WF{render(){const e=(0,r.qy)(s||(s=p`<div class="header-title"> <slot name="title"></slot> </div>`)),a=(0,r.qy)(l||(l=p`<div class="header-subtitle"> <slot name="subtitle"></slot> </div>`));return(0,r.qy)(d||(d=p` <header class="header"> <div class="header-bar"> <section class="header-navigation-icon"> <slot name="navigationIcon"></slot> </section> <section class="header-content"> ${0} </section> <section class="header-action-items"> <slot name="actionItems"></slot> </section> </div> <slot></slot> </header> `),"above"===this.subtitlePosition?(0,r.qy)(h||(h=p`${0}${0}`),a,e):(0,r.qy)(n||(n=p`${0}${0}`),e,a))}static get styles(){return[(0,r.AH)(c||(c=p`:host{display:block}:host([show-border]){border-bottom:1px solid var(--mdc-dialog-scroll-divider-color,rgba(0,0,0,.12))}.header-bar{display:flex;flex-direction:row;align-items:center;padding:0 var(--ha-space-1);box-sizing:border-box}.header-content{flex:1;padding:10px var(--ha-space-1);display:flex;flex-direction:column;justify-content:center;min-height:var(--ha-space-12);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.header-title{height:var(--ha-dialog-header-title-height,calc(var(--ha-font-size-xl) + var(--ha-space-1)));font-size:var(--ha-font-size-xl);line-height:var(--ha-line-height-condensed);font-weight:var(--ha-font-weight-medium);color:var(--ha-dialog-header-title-color,var(--primary-text-color))}.header-subtitle{font-size:var(--ha-font-size-m);line-height:var(--ha-line-height-normal);color:var(--ha-dialog-header-subtitle-color,var(--secondary-text-color))}@media all and (min-width:450px) and (min-height:500px){.header-bar{padding:0 var(--ha-space-2)}}.header-navigation-icon{flex:none;min-width:var(--ha-space-2);height:100%;display:flex;flex-direction:row}.header-action-items{flex:none;min-width:var(--ha-space-2);height:100%;display:flex;flex-direction:row}`))]}constructor(...e){super(...e),this.subtitlePosition="below",this.showBorder=!1}}(0,o.Cg)([(0,i.MZ)({type:String,attribute:"subtitle-position"})],g.prototype,"subtitlePosition",void 0),(0,o.Cg)([(0,i.MZ)({type:Boolean,reflect:!0,attribute:"show-border"})],g.prototype,"showBorder",void 0),g=(0,o.Cg)([(0,i.EM)("ha-dialog-header")],g)},2846:function(e,a,t){t.d(a,{G:function(){return p},J:function(){return c}});var o=t(40445),r=t(97154),i=t(82553),s=t(96196),l=t(77845);t(54276);let d,h,n=e=>e;const c=[i.R,(0,s.AH)(d||(d=n`:host{--ha-icon-display:block;--md-sys-color-primary:var(--primary-text-color);--md-sys-color-secondary:var(--secondary-text-color);--md-sys-color-surface:var(--card-background-color);--md-sys-color-on-surface:var(--primary-text-color);--md-sys-color-on-surface-variant:var(--secondary-text-color)}md-item{overflow:var(--md-item-overflow,hidden);align-items:var(--md-item-align-items,center);gap:var(--ha-md-list-item-gap,16px)}`))];class p extends r.n{renderRipple(){return"text"===this.type?s.s6:(0,s.qy)(h||(h=n`<ha-ripple part="ripple" for="item" ?disabled="${0}"></ha-ripple>`),this.disabled&&"link"!==this.type)}}p.styles=c,p=(0,o.Cg)([(0,l.EM)("ha-md-list-item")],p)},17308:function(e,a,t){var o=t(40445),r=t(49838),i=t(11245),s=t(96196),l=t(77845);let d;class h extends r.B{}h.styles=[i.R,(0,s.AH)(d||(d=(e=>e)`:host{--md-sys-color-surface:var(--card-background-color)}`))],h=(0,o.Cg)([(0,l.EM)("ha-md-list")],h)},45331:function(e,a,t){t.a(e,async function(e,a){try{t(3362),t(62953);var o=t(40445),r=t(93900),i=t(96196),s=t(77845),l=t(32288),d=t(1087),h=t(59992),n=t(14503),c=(t(76538),t(26300),e([r,h]));[r,h]=c.then?(await c)():c;let p,g,v,u,f,m,b,y=e=>e;const _="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z";class w extends((0,h.V)(i.WF)){get scrollableElement(){return this.bodyContainer}updated(e){super.updated(e),e.has("open")&&(this._open=this.open)}render(){var e,a;return(0,i.qy)(p||(p=y` <wa-dialog .open="${0}" .lightDismiss="${0}" without-header aria-labelledby="${0}" aria-describedby="${0}" @keydown="${0}" @wa-hide="${0}" @wa-show="${0}" @wa-after-show="${0}" @wa-after-hide="${0}"> ${0} <div class="content-wrapper"> <div class="body ha-scrollbar" @scroll="${0}"> <slot></slot> </div> ${0} </div> <slot name="footer" slot="footer"></slot> </wa-dialog> `),this._open,!this.preventScrimClose,(0,l.J)(this.ariaLabelledBy||(void 0!==this.headerTitle?"ha-wa-dialog-title":void 0)),(0,l.J)(this.ariaDescribedBy),this._handleKeyDown,this._handleHide,this._handleShow,this._handleAfterShow,this._handleAfterHide,this.withoutHeader?i.s6:(0,i.qy)(g||(g=y` <slot name="header"> <ha-dialog-header .subtitlePosition="${0}" .showBorder="${0}"> <slot name="headerNavigationIcon" slot="navigationIcon"> <ha-icon-button data-dialog="close" .label="${0}" .path="${0}"></ha-icon-button> </slot> ${0} ${0} <slot name="headerActionItems" slot="actionItems"></slot> </ha-dialog-header> </slot>`),this.headerSubtitlePosition,this._bodyScrolled,null!==(e=null===(a=this.hass)||void 0===a?void 0:a.localize("ui.common.close"))&&void 0!==e?e:"Close",_,void 0!==this.headerTitle?(0,i.qy)(v||(v=y`<span slot="title" class="title" id="ha-wa-dialog-title"> ${0} </span>`),this.headerTitle):(0,i.qy)(u||(u=y`<slot name="headerTitle" slot="title"></slot>`)),void 0!==this.headerSubtitle?(0,i.qy)(f||(f=y`<span slot="subtitle">${0}</span>`),this.headerSubtitle):(0,i.qy)(m||(m=y`<slot name="headerSubtitle" slot="subtitle"></slot>`))),this._handleBodyScroll,this.renderScrollableFades())}disconnectedCallback(){super.disconnectedCallback(),this._open=!1}_handleBodyScroll(e){this._bodyScrolled=e.target.scrollTop>0}_handleKeyDown(e){"Escape"===e.key&&(this._escapePressed=!0)}_handleHide(e){this.preventScrimClose&&this._escapePressed&&e.detail.source===e.target.dialog&&e.preventDefault(),this._escapePressed=!1}static get styles(){return[...super.styles,n.dp,(0,i.AH)(b||(b=y`
        wa-dialog {
          --full-width: var(
            --ha-dialog-width-full,
            min(95vw, var(--safe-width))
          );
          --width: min(var(--ha-dialog-width-md, 580px), var(--full-width));
          --spacing: var(--dialog-content-padding, var(--ha-space-6));
          --show-duration: var(--ha-dialog-show-duration, 200ms);
          --hide-duration: var(--ha-dialog-hide-duration, 200ms);
          --ha-dialog-surface-background: var(
            --card-background-color,
            var(--ha-color-surface-default)
          );
          --wa-color-surface-raised: var(
            --ha-dialog-surface-background,
            var(--card-background-color, var(--ha-color-surface-default))
          );
          --wa-panel-border-radius: var(
            --ha-dialog-border-radius,
            var(--ha-border-radius-3xl)
          );
          max-width: var(--ha-dialog-max-width, var(--safe-width));
        }
        @media (prefers-reduced-motion: reduce) {
          wa-dialog {
            --show-duration: 0ms;
            --hide-duration: 0ms;
          }
        }

        :host([width="small"]) wa-dialog {
          --width: min(var(--ha-dialog-width-sm, 320px), var(--full-width));
        }

        :host([width="large"]) wa-dialog {
          --width: min(var(--ha-dialog-width-lg, 1024px), var(--full-width));
        }

        :host([width="full"]) wa-dialog {
          --width: var(--full-width);
        }

        wa-dialog::part(dialog) {
          color: var(--primary-text-color);
          min-width: var(--width, var(--full-width));
          max-width: var(--width, var(--full-width));
          max-height: var(
            --ha-dialog-max-height,
            calc(var(--safe-height) - var(--ha-space-20))
          );
          min-height: var(--ha-dialog-min-height);
          margin-top: var(--dialog-surface-margin-top, auto);
          /* Used to offset the dialog from the safe areas when space is limited */
          transform: translate(
            calc(
              var(--safe-area-offset-left, 0px) - var(
                  --safe-area-offset-right,
                  0px
                )
            ),
            calc(
              var(--safe-area-offset-top, 0px) - var(
                  --safe-area-offset-bottom,
                  0px
                )
            )
          );
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        @media all and (max-width: 450px), all and (max-height: 500px) {
          :host([type="standard"]) {
            --ha-dialog-border-radius: 0;

            wa-dialog {
              /* Make the container fill the whole screen width and not the safe width */
              --full-width: var(--ha-dialog-width-full, 100vw);
              --width: var(--full-width);
            }

            wa-dialog::part(dialog) {
              /* Make the dialog fill the whole screen height and not the safe height */
              min-height: var(--ha-dialog-min-height, 100vh);
              min-height: var(--ha-dialog-min-height, 100dvh);
              max-height: var(--ha-dialog-max-height, 100vh);
              max-height: var(--ha-dialog-max-height, 100dvh);
              margin-top: 0;
              margin-bottom: 0;
              /* Use safe area as padding instead of the container size */
              padding-top: var(--safe-area-inset-top);
              padding-bottom: var(--safe-area-inset-bottom);
              padding-left: var(--safe-area-inset-left);
              padding-right: var(--safe-area-inset-right);
              /* Reset the transform to center the dialog */
              transform: none;
            }
          }
        }

        .header-title-container {
          display: flex;
          align-items: center;
        }

        .header-title {
          margin: 0;
          margin-bottom: 0;
          color: var(--ha-dialog-header-title-color, var(--primary-text-color));
          font-size: var(
            --ha-dialog-header-title-font-size,
            var(--ha-font-size-2xl)
          );
          line-height: var(
            --ha-dialog-header-title-line-height,
            var(--ha-line-height-condensed)
          );
          font-weight: var(
            --ha-dialog-header-title-font-weight,
            var(--ha-font-weight-normal)
          );
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          margin-right: var(--ha-space-3);
        }

        wa-dialog::part(body) {
          padding: 0;
          display: flex;
          flex-direction: column;
          max-width: 100%;
          overflow: hidden;
        }

        .content-wrapper {
          position: relative;
          flex: 1;
          display: flex;
          flex-direction: column;
          min-height: 0;
        }

        .body {
          position: var(--dialog-content-position, relative);
          padding: var(
            --dialog-content-padding,
            0 var(--ha-space-6) var(--ha-space-6) var(--ha-space-6)
          );
          overflow: auto;
          flex-grow: 1;
        }
        :host([flexcontent]) .body {
          max-width: 100%;
          flex: 1;
          display: flex;
          flex-direction: column;
        }

        wa-dialog::part(footer) {
          padding: 0;
        }

        ::slotted([slot="footer"]) {
          display: flex;
          padding: var(--ha-space-3) var(--ha-space-4) var(--ha-space-4)
            var(--ha-space-4);
          gap: var(--ha-space-3);
          justify-content: flex-end;
          align-items: center;
          width: 100%;
        }
      `))]}constructor(...e){super(...e),this.open=!1,this.type="standard",this.width="medium",this.preventScrimClose=!1,this.headerSubtitlePosition="below",this.flexContent=!1,this.withoutHeader=!1,this._open=!1,this._bodyScrolled=!1,this._escapePressed=!1,this._handleShow=async()=>{this._open=!0,(0,d.r)(this,"opened"),await this.updateComplete,requestAnimationFrame(()=>{var e;null===(e=this.querySelector("[autofocus]"))||void 0===e||e.focus()})},this._handleAfterShow=()=>{(0,d.r)(this,"after-show")},this._handleAfterHide=e=>{e.eventPhase===Event.AT_TARGET&&(this._open=!1,(0,d.r)(this,"closed"))}}}(0,o.Cg)([(0,s.MZ)({attribute:!1})],w.prototype,"hass",void 0),(0,o.Cg)([(0,s.MZ)({attribute:"aria-labelledby"})],w.prototype,"ariaLabelledBy",void 0),(0,o.Cg)([(0,s.MZ)({attribute:"aria-describedby"})],w.prototype,"ariaDescribedBy",void 0),(0,o.Cg)([(0,s.MZ)({type:Boolean,reflect:!0})],w.prototype,"open",void 0),(0,o.Cg)([(0,s.MZ)({reflect:!0})],w.prototype,"type",void 0),(0,o.Cg)([(0,s.MZ)({type:String,reflect:!0,attribute:"width"})],w.prototype,"width",void 0),(0,o.Cg)([(0,s.MZ)({type:Boolean,reflect:!0,attribute:"prevent-scrim-close"})],w.prototype,"preventScrimClose",void 0),(0,o.Cg)([(0,s.MZ)({attribute:"header-title"})],w.prototype,"headerTitle",void 0),(0,o.Cg)([(0,s.MZ)({attribute:"header-subtitle"})],w.prototype,"headerSubtitle",void 0),(0,o.Cg)([(0,s.MZ)({type:String,attribute:"header-subtitle-position"})],w.prototype,"headerSubtitlePosition",void 0),(0,o.Cg)([(0,s.MZ)({type:Boolean,reflect:!0,attribute:"flexcontent"})],w.prototype,"flexContent",void 0),(0,o.Cg)([(0,s.MZ)({type:Boolean,attribute:"without-header"})],w.prototype,"withoutHeader",void 0),(0,o.Cg)([(0,s.wk)()],w.prototype,"_open",void 0),(0,o.Cg)([(0,s.P)(".body")],w.prototype,"bodyContainer",void 0),(0,o.Cg)([(0,s.wk)()],w.prototype,"_bodyScrolled",void 0),(0,o.Cg)([(0,s.Ls)({passive:!0})],w.prototype,"_handleBodyScroll",null),w=(0,o.Cg)([(0,s.EM)("ha-wa-dialog")],w),a()}catch(p){a(p)}})},59992:function(e,a,t){t.a(e,async function(e,o){try{t.d(a,{V:function(){return v}});t(62953);var r=t(40445),i=t(88696),s=t(96196),l=t(94333),d=t(77845),h=e([i]);i=(h.then?(await h)():h)[0];let n,c,p=e=>e;const g=e=>void 0===e?[]:Array.isArray(e)?e:[e],v=e=>{class a extends e{get scrollableElement(){return a.DEFAULT_SCROLLABLE_ELEMENT}firstUpdated(e){var a;null===(a=super.firstUpdated)||void 0===a||a.call(this,e),this.scrollableElement&&this._updateScrollableState(this.scrollableElement),this._attachScrollableElement()}updated(e){var a;null===(a=super.updated)||void 0===a||a.call(this,e),this._attachScrollableElement()}disconnectedCallback(){this._detachScrollableElement(),this._contentScrolled=!1,this._contentScrollable=!1,super.disconnectedCallback()}renderScrollableFades(e=!1){return(0,s.qy)(n||(n=p` <div class="${0}"></div> <div class="${0}"></div> `),(0,l.H)({"fade-top":!0,rounded:e,visible:this._contentScrolled}),(0,l.H)({"fade-bottom":!0,rounded:e,visible:this._contentScrollable}))}static get styles(){var e;const a=Object.getPrototypeOf(this);return[...g(null!==(e=null==a?void 0:a.styles)&&void 0!==e?e:[]),(0,s.AH)(c||(c=p`.fade-bottom,.fade-top{position:absolute;left:0;right:0;height:var(--ha-space-2);pointer-events:none;transition:opacity 180ms ease-in-out;border-radius:var(--ha-border-radius-square);opacity:0;background:linear-gradient(to bottom,var(--ha-color-shadow-scrollable-fade),transparent)}.fade-top{top:0}.fade-bottom{bottom:0;transform:rotate(180deg)}.fade-bottom.visible,.fade-top.visible{opacity:1}.fade-bottom.rounded,.fade-top.rounded{border-radius:var(--ha-card-border-radius,var(--ha-border-radius-lg));border-bottom-left-radius:var(--ha-border-radius-square);border-bottom-right-radius:var(--ha-border-radius-square)}.fade-top.rounded{border-top-left-radius:var(--ha-border-radius-square);border-top-right-radius:var(--ha-border-radius-square)}.fade-bottom.rounded{border-bottom-left-radius:var(--ha-border-radius-square);border-bottom-right-radius:var(--ha-border-radius-square)}`))]}_attachScrollableElement(){const e=this.scrollableElement;e!==this._scrollTarget&&(this._detachScrollableElement(),e&&(this._scrollTarget=e,e.addEventListener("scroll",this._onScroll,{passive:!0}),this._resize.observe(e),this._updateScrollableState(e)))}_detachScrollableElement(){var e,a;this._scrollTarget&&(this._scrollTarget.removeEventListener("scroll",this._onScroll),null===(e=(a=this._resize).unobserve)||void 0===e||e.call(a,this._scrollTarget),this._scrollTarget=void 0)}_updateScrollableState(e){const a=parseFloat(getComputedStyle(e).getPropertyValue("--safe-area-inset-bottom"))||0,{scrollHeight:t=0,clientHeight:o=0,scrollTop:r=0}=e;this._contentScrollable=t-o>r+a+this.scrollFadeSafeAreaPadding}constructor(...e){super(...e),this._contentScrolled=!1,this._contentScrollable=!1,this._onScroll=e=>{var a;const t=e.currentTarget;this._contentScrolled=(null!==(a=t.scrollTop)&&void 0!==a?a:0)>this.scrollFadeThreshold,this._updateScrollableState(t)},this._resize=new i.P(this,{target:null,callback:e=>{var a;const t=null===(a=e[0])||void 0===a?void 0:a.target;t&&this._updateScrollableState(t)}}),this.scrollFadeSafeAreaPadding=4,this.scrollFadeThreshold=4}}return a.DEFAULT_SCROLLABLE_ELEMENT=null,(0,r.Cg)([(0,d.wk)()],a.prototype,"_contentScrolled",void 0),(0,r.Cg)([(0,d.wk)()],a.prototype,"_contentScrollable",void 0),a};o()}catch(n){o(n)}})},54607:function(e,a,t){t.a(e,async function(e,o){try{t.r(a);t(44114),t(18111),t(22489),t(61701),t(3362),t(62953);var r=t(40445),i=t(96196),s=t(77845),l=t(4937),d=t(66639),h=t(1087),n=t(18350),c=(t(93444),t(18198),t(88945),t(17308),t(2846),t(85938),t(67094),t(45331)),p=t(53641),g=t(32250),v=t(14503),u=t(81619),f=e([n,c]);[n,c]=f.then?(await f)():f;let m,b,y,_,w,x,S,$,C,M,A=e=>e;const L="M21 11H3V9H21V11M21 13H3V15H21V13Z",k="M20 2H4C2.9 2 2 2.9 2 4V20C2 21.11 2.9 22 4 22H20C21.11 22 22 21.11 22 20V4C22 2.9 21.11 2 20 2M4 6L6 4H10.9L4 10.9V6M4 13.7L13.7 4H18.6L4 18.6V13.7M20 18L18 20H13.1L20 13.1V18M20 10.3L10.3 20H5.4L20 5.4V10.3Z",q="__unassigned__";class E extends i.WF{async showDialog(e){this._open=!0,this._computeHierarchy()}_computeHierarchy(){this._hierarchy=(0,d.cs)(Object.values(this.hass.floors),Object.values(this.hass.areas))}closeDialog(){this._saving=!1,this._open=!1}_dialogClosed(){this._open=!1,this._hierarchy=void 0,this._saving=!1,(0,h.r)(this,"dialog-closed",{dialog:this.localName})}render(){if(!this._hierarchy)return i.s6;const e=this._hierarchy.floors.length>0,a=this.hass.localize(e?"ui.panel.config.areas.dialog.reorder_floors_areas_title":"ui.panel.config.areas.dialog.reorder_areas_title");return(0,i.qy)(m||(m=A` <ha-wa-dialog .hass="${0}" .open="${0}" header-title="${0}" @closed="${0}"> <div class="content"> <ha-sortable handle-selector=".floor-handle" draggable-selector=".floor" @item-moved="${0}" invert-swap> <div class="floors"> ${0} </div> </ha-sortable> ${0} </div> <ha-dialog-footer slot="footer"> <ha-button slot="secondaryAction" @click="${0}" appearance="plain"> ${0} </ha-button> <ha-button slot="primaryAction" @click="${0}" .disabled="${0}"> ${0} </ha-button> </ha-dialog-footer> </ha-wa-dialog> `),this.hass,this._open,a,this._dialogClosed,this._floorMoved,(0,l.u)(this._hierarchy.floors,e=>e.id,e=>this._renderFloor(e)),this._renderUnassignedAreas(),this.closeDialog,this.hass.localize("ui.common.cancel"),this._save,this._saving,this.hass.localize("ui.common.save"))}_renderFloor(e){const a=this.hass.floors[e.id];return a?(0,i.qy)(b||(b=A` <div class="floor"> <div class="floor-header"> <ha-floor-icon .floor="${0}"></ha-floor-icon> <span class="floor-name">${0}</span> <ha-svg-icon class="floor-handle" .path="${0}"></ha-svg-icon> </div> <ha-sortable handle-selector=".area-handle" draggable-selector="ha-md-list-item" @item-moved="${0}" @item-added="${0}" group="areas" .floor="${0}"> <ha-md-list> ${0} </ha-md-list> </ha-sortable> </div> `),a,a.name,L,this._areaMoved,this._areaAdded,e.id,e.areas.length>0?e.areas.map(e=>this._renderArea(e)):(0,i.qy)(y||(y=A`<p class="empty"> ${0} </p>`),this.hass.localize("ui.panel.config.areas.dialog.empty_floor"))):i.s6}_renderUnassignedAreas(){const e=this._hierarchy.floors.length>0;return(0,i.qy)(_||(_=A` <div class="floor unassigned"> ${0} <ha-sortable handle-selector=".area-handle" draggable-selector="ha-md-list-item" @item-moved="${0}" @item-added="${0}" group="areas" .floor="${0}"> <ha-md-list> ${0} </ha-md-list> </ha-sortable> </div> `),e?(0,i.qy)(w||(w=A`<div class="floor-header"> <span class="floor-name"> ${0} </span> </div>`),this.hass.localize("ui.panel.config.areas.dialog.other_areas")):i.s6,this._areaMoved,this._areaAdded,q,this._hierarchy.areas.length>0?this._hierarchy.areas.map(e=>this._renderArea(e)):(0,i.qy)(x||(x=A`<p class="empty"> ${0} </p>`),this.hass.localize("ui.panel.config.areas.dialog.empty_unassigned")))}_renderArea(e){const a=this.hass.areas[e];return a?(0,i.qy)(S||(S=A` <ha-md-list-item .sortableData="${0}"> ${0} <span slot="headline">${0}</span> <ha-svg-icon class="area-handle" slot="end" .path="${0}"></ha-svg-icon> </ha-md-list-item> `),a,a.icon?(0,i.qy)($||($=A`<ha-icon slot="start" .icon="${0}"></ha-icon>`),a.icon):(0,i.qy)(C||(C=A`<ha-svg-icon slot="start" .path="${0}"></ha-svg-icon>`),k),a.name,L):i.s6}_floorMoved(e){if(e.stopPropagation(),!this._hierarchy)return;const{oldIndex:a,newIndex:t}=e.detail,o=[...this._hierarchy.floors],[r]=o.splice(a,1);o.splice(t,0,r),this._hierarchy=Object.assign(Object.assign({},this._hierarchy),{},{floors:o})}_areaMoved(e){if(e.stopPropagation(),!this._hierarchy)return;const{floor:a}=e.currentTarget,{oldIndex:t,newIndex:o}=e.detail,r=a===q?null:a;if(null===r){const e=[...this._hierarchy.areas],[a]=e.splice(t,1);e.splice(o,0,a),this._hierarchy=Object.assign(Object.assign({},this._hierarchy),{},{areas:e})}else this._hierarchy=Object.assign(Object.assign({},this._hierarchy),{},{floors:this._hierarchy.floors.map(e=>{if(e.id===r){const a=[...e.areas],[r]=a.splice(t,1);return a.splice(o,0,r),Object.assign(Object.assign({},e),{},{areas:a})}return e})})}_areaAdded(e){if(e.stopPropagation(),!this._hierarchy)return;const{floor:a}=e.currentTarget,{data:t,index:o}=e.detail,r=a===q?null:a,i=this._hierarchy.areas.filter(e=>e!==t.area_id);null===r&&i.splice(o,0,t.area_id),this._hierarchy=Object.assign(Object.assign({},this._hierarchy),{},{floors:this._hierarchy.floors.map(e=>{if(e.id===r){const a=[...e.areas];return a.splice(o,0,t.area_id),Object.assign(Object.assign({},e),{},{areas:a})}return Object.assign(Object.assign({},e),{},{areas:e.areas.filter(e=>e!==t.area_id)})}),areas:i})}_computeFloorChanges(){if(!this._hierarchy)return[];const e=[];for(const i of this._hierarchy.floors)for(const o of i.areas){var a,t;const r=null!==(a=null===(t=this.hass.areas[o])||void 0===t?void 0:t.floor_id)&&void 0!==a?a:null;i.id!==r&&e.push({areaId:o,floorId:i.id})}for(const i of this._hierarchy.areas){var o,r;null!==(null!==(o=null===(r=this.hass.areas[i])||void 0===r?void 0:r.floor_id)&&void 0!==o?o:null)&&e.push({areaId:i,floorId:null})}return e}async _save(){if(this._hierarchy&&!this._saving){this._saving=!0;try{const e=(0,d.Xz)(this._hierarchy),a=(0,d.Vu)(this._hierarchy),t=this._computeFloorChanges().map(({areaId:e,floorId:a})=>(0,p.gs)(this.hass,e,{floor_id:a}));await Promise.all(t),await(0,p.WT)(this.hass,e),await(0,g.Rj)(this.hass,a),this.closeDialog()}catch(e){(0,u.P)(this,{message:e.message||this.hass.localize("ui.panel.config.areas.dialog.reorder_failed")}),this._saving=!1}}}static get styles(){return[v.RF,v.nA,(0,i.AH)(M||(M=A`ha-wa-dialog{max-height:90%;--dialog-content-padding:var(--ha-space-2) var(--ha-space-6)}@media all and (max-width:580px),all and (max-height:500px){ha-wa-dialog{min-width:100%;min-height:100%}}.floors{display:flex;flex-direction:column;gap:16px}.floor{border:1px solid var(--divider-color);border-radius:var(--ha-card-border-radius,var(--ha-border-radius-lg));overflow:hidden}.floor.unassigned{margin-top:16px}.floor-header{display:flex;align-items:center;padding:12px 16px;background-color:var(--secondary-background-color);gap:12px}.floor-name{flex:1;font-weight:var(--ha-font-weight-medium)}.floor-handle{cursor:grab;color:var(--secondary-text-color)}ha-md-list{padding:0;--md-list-item-leading-space:16px;--md-list-item-trailing-space:16px;display:flex;flex-direction:column}ha-md-list-item{--md-list-item-one-line-container-height:48px;--md-list-item-container-shape:0}ha-md-list-item.sortable-ghost{border-radius:calc(var(--ha-card-border-radius,var(--ha-border-radius-lg)) - 1px);box-shadow:inset 0 0 0 2px var(--primary-color)}.area-handle{cursor:grab;color:var(--secondary-text-color)}.empty{text-align:center;color:var(--secondary-text-color);font-style:italic;margin:0;padding:12px 16px;order:1}ha-md-list:has(ha-md-list-item) .empty{display:none}.content{padding-top:16px;padding-bottom:16px}`))]}constructor(...e){super(...e),this._open=!1,this._saving=!1}}(0,r.Cg)([(0,s.MZ)({attribute:!1})],E.prototype,"hass",void 0),(0,r.Cg)([(0,s.wk)()],E.prototype,"_open",void 0),(0,r.Cg)([(0,s.wk)()],E.prototype,"_hierarchy",void 0),(0,r.Cg)([(0,s.wk)()],E.prototype,"_saving",void 0),E=(0,r.Cg)([(0,s.EM)("dialog-areas-floors-order")],E),o()}catch(m){o(m)}})}}]);
//# sourceMappingURL=6660.2b760297c5acc0a6.js.map